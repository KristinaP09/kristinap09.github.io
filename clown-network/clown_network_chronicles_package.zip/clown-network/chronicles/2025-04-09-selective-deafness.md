---
layout: page
title: "Selective Deafness Incident"
permalink: /clown-network/chronicles/selective-deafness-incident/
---

## April 9, 2025 – Selective Deafness Incident

A brilliant display of sonic duality. After dragging furniture around the bathroom like a lost pirate map, the tenant downstairs knocked — only to be met with total silence. A masterclass in ignoring people while making noise.

Award-worthy.
